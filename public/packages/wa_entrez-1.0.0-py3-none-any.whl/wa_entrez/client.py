"""
WebAssembly-compatible client for the NCBI Entrez E-utilities API.

This client provides a lightweight interface for querying the Entrez API
from environments such as WebAssembly (Pyodide) where traditional HTTP
libraries may not work.

It automatically:
- builds valid Entrez query parameters
- switches between GET and POST when URLs become too long
- allows a custom transport layer
"""

from .utils import _construct_params, encode_params
from .transport import get_default_transport


class WAEntrezClient:
    """
    Client for accessing the NCBI Entrez E-utilities API.

    Designed specifically for WebAssembly environments (e.g. Pyodide)
    where traditional HTTP libraries may not be available.

    Parameters
    ----------
    email : Email address required by NCBI to identify the user.
    tool : Name of the application making the request.
    api_key : NCBI API key. Increases rate limits.
    transport : callable, optional
        Custom transport function used to perform HTTP requests.
        Must have the signature:
            transport(url, method="GET", data=None)
    """

    BASE_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/"

    def __init__(self, email=None, tool="biopython", api_key=None, transport=None):
        self.email = email
        self.tool = tool
        self.api_key = api_key
        self.transport = transport or get_default_transport()

    def _build_url(self, endpoint, params, post=None, join_ids=True):
        """
        Construct the request URL and determine whether GET or POST
        should be used.

        NCBI recommends POST when:
        - the query string exceeds ~1000 characters
        - more than 200 IDs are provided
        """

        params = _construct_params(
            params,
            tool=self.tool,
            email=self.email,
            api_key=self.api_key,
            join_ids=join_ids,
        )

        params_str = encode_params(params)

        # Automatically switch to POST if the URL becomes too long
        if post is None and len(params_str) > 1000:
            post = True

        # Also switch to POST if too many IDs are included
        if post is None and "id" in params:
            id_count = params["id"].count(",") + 1
            if id_count > 200:
                post = True

        if post:
            return endpoint, "POST", params_str.encode("utf-8")

        return endpoint + "?" + params_str, "GET", None

    def _request(self, endpoint, params=None, post=None, join_ids=True):
        """
        Perform the HTTP request using the configured transport layer.
        """

        url, method, data = self._build_url(
            endpoint,
            params,
            post=post,
            join_ids=join_ids,
        )

        return self.transport.request(url, method=method, data=data)

    # ---------------------------------------------------------
    # Entrez API endpoints
    # ---------------------------------------------------------

    def wa_efetch(self, db, **kwargs):
        """
        Call the efetch endpoint.

        Used to retrieve full records from Entrez databases.
        """
        endpoint = self.BASE_URL + "efetch.fcgi"
        params = {"db": db}
        params.update(kwargs)

        return self._request(endpoint, params=params)

    def wa_esearch(self, db, term, **kwargs):
        """
        Call the esearch endpoint.

        Used to search for record IDs matching a query.
        """
        endpoint = self.BASE_URL + "esearch.fcgi"
        params = {"db": db, "term": term}
        params.update(kwargs)

        return self._request(endpoint, params=params)

    def wa_elink(self, **kwargs):
        """
        Call the elink endpoint.

        Used to find related records across Entrez databases.
        """
        endpoint = self.BASE_URL + "elink.fcgi"
        params = {}
        params.update(kwargs)

        return self._request(endpoint, params=params, join_ids=False)

    def wa_einfo(self, **kwargs):
        """
        Call the einfo endpoint.

        Returns metadata about available Entrez databases.
        """
        endpoint = self.BASE_URL + "einfo.fcgi"

        return self._request(endpoint, params=kwargs)

    def wa_esummary(self, **kwargs):
        """
        Call the esummary endpoint.

        Retrieves document summaries for a list of IDs.
        """
        endpoint = self.BASE_URL + "esummary.fcgi"

        return self._request(endpoint, params=kwargs)