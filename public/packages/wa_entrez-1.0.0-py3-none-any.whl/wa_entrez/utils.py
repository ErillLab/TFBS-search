"""
Utility functions used by the WAEntrez client.
"""

from urllib.parse import urlencode


def format_id(ids):
    """
    Normalize Entrez ID parameters.

    Accepts:
    - a single integer
    - a comma-separated string
    - an iterable of IDs

    Returns
    -------
    str
        Comma-separated ID string.
    """

    if isinstance(ids, int):
        return str(ids)

    if isinstance(ids, str):
        return ",".join(id.strip() for id in ids.split(","))

    # Assume iterable
    return ",".join(map(str, ids))


def _construct_params(params, tool=None, email=None, api_key=None, join_ids=True):
    """
    Construct and normalize request parameters.

    Adds standard Entrez parameters (tool, email, api_key)
    and removes None values.

    Raises
    ------
    ValueError
        If the email parameter is not provided.
    """

    if params is None:
        params = {}
    else:
        params = params.copy()

    params.setdefault("tool", tool)
    params.setdefault("email", email)
    params.setdefault("api_key", api_key)

    # Remove parameters with None values
    for key, value in list(params.items()):
        if value is None:
            del params[key]

    if "email" not in params:
        raise ValueError(
            "Email is required for NCBI Entrez API requests. "
            "Please provide an email address."
        )

    if join_ids and "id" in params:
        params["id"] = format_id(params["id"])

    return params


def encode_params(params):
    """
    URL-encode request parameters.

    Uses `doseq=True` to correctly encode repeated parameters.
    """
    return urlencode(params, doseq=True)