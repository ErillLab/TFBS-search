from pyodide.http import open_url, pyfetch
import asyncio

    
async def _request_async(url, method="GET", data=None):
    response = await pyfetch(
        url,
        method=method,
        body=data,
        headers={"Content-Type": "application/x-www-form-urlencoded"} if data else None,
    )
    return await response.text()

def request(url, method="GET", data=None):
    """
    Synchronous wrapper for the asynchronous _request_async function.
    This allows us to use the same interface for both synchronous and asynchronous transports.
    Works even if theres an event loop or not, by creating a new event loop if necessary.
    """
    
   
    
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        # No event loop is running, we can use normal Python code to run the async function.
        coroutine = asyncio.run(_request_async(url, method, data))
    else:
        # An event loop is already running, we need to create a new task for the async function and wait for it to complete.
        # return asyncio.create_task(_request_async(url, method, data))
        # return loop.create_task(_request_async(url, method, data))
        coroutine = _request_async(url, method, data)
    
    
    
    
    return coroutine
       


# class DefaultTransport:
#     """
#     Default HTTP transport implementation.
    
#     Uses pyodide.http open_url internally with a fallback to pyfetch for POST requests.
#     A GET request is made when Data is None.
#     A POST request is made when Data is not None.
    
#     This is a simple implementation that can be used as a default transport for the WAEntrezClient. It can be easily replaced with a custom transport that implements the same interface.
#     """
    
#     async def request(self, url, method="GET", data=None):
#         # pyodide.http.open_url does not support POST requests.
#         # We will use pyfetch for POST requests.
#         if method == "GET":
#             return open_url(url).read()
#         elif method == "POST":
#             # POST -> use pyfetch
#             reponse = await pyfetch(
#                 url,
#                 method="POST",
#                 body=data,
#                 headers={"Content-Type": "application/x-www-form-urlencoded"}
#             )
#             return await reponse.text()